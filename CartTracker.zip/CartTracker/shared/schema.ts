import { pgTable, text, serial, doublePrecision, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: doublePrecision("price").notNull(),
  imageData: text("image_data").notNull(), // Base64 encoded image
  createdAt: timestamp("created_at").defaultNow().notNull(),
  purchaseId: text("purchase_id"), // Used to link with shopping list items
});

// New schema for shopping list items
export const shoppingListItems = pgTable("shopping_list_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  estimatedPrice: doublePrecision("estimated_price").notNull(),
  quantity: text("quantity").notNull(), // e.g. "2 kg", "3 pieces"
  isBought: boolean("is_bought").default(false).notNull(),
  actualPrice: doublePrecision("actual_price"),
  imageData: text("image_data"), // Optional until bought
  createdAt: timestamp("created_at").defaultNow().notNull(),
  tripId: serial("trip_id").notNull(), // Reference to current shopping trip
  purchaseId: text("purchase_id"), // Used to link with purchased items
});

export const insertItemSchema = createInsertSchema(items).omit({ id: true, createdAt: true, purchaseId: true });
export const insertShoppingListItemSchema = createInsertSchema(shoppingListItems).omit({ 
  id: true, 
  createdAt: true,
  isBought: true,
  actualPrice: true,
  imageData: true,
  purchaseId: true
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;

export type InsertShoppingListItem = z.infer<typeof insertShoppingListItemSchema>;
export type ShoppingListItem = typeof shoppingListItems.$inferSelect;

// Categories for shopping list items
export const itemCategories = [
  "Rau củ",
  "Thịt",
  "Cá",
  "Trứng sữa",
  "Gia vị",
  "Đồ khô",
  "Đồ uống",
  "Khác"
] as const;

export const shoppingListItemSchema = z.object({
  name: z.string().min(1, "Tên món không được để trống"),
  category: z.enum(itemCategories),
  estimatedPrice: z.number().min(0, "Giá dự kiến phải lớn hơn 0"),
  quantity: z.string().min(1, "Số lượng không được để trống"),
  tripId: z.number()
});