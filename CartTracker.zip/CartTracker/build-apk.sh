#!/bin/bash

# Build web app
npm run build

# Update Android project
npx cap sync android

# Generate debug APK
cd android
./gradlew assembleDebug

# APK will be at: android/app/build/outputs/apk/debug/app-debug.apk
echo "APK generated at: android/app/build/outputs/apk/debug/app-debug.apk"
