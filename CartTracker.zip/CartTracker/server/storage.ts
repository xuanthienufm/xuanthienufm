import { items, type Item, type InsertItem } from "@shared/schema";

export interface IStorage {
  getItems(): Promise<Item[]>;
  addItem(item: InsertItem): Promise<Item>;
  deleteItem(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private items: Map<number, Item>;
  private currentId: number;

  constructor() {
    this.items = new Map();
    this.currentId = 1;

    // Load items from localStorage if available
    if (typeof window !== 'undefined') {
      const savedItems = localStorage.getItem('shopping-cart');
      if (savedItems) {
        const parsedItems = JSON.parse(savedItems);
        parsedItems.forEach((item: Item) => {
          this.items.set(item.id, item);
          // Update currentId to be greater than any existing id
          if (item.id >= this.currentId) {
            this.currentId = item.id + 1;
          }
        });
      }
    }
  }

  private saveToLocalStorage() {
    if (typeof window !== 'undefined') {
      localStorage.setItem('shopping-cart', JSON.stringify(Array.from(this.items.values())));
    }
  }

  async getItems(): Promise<Item[]> {
    return Array.from(this.items.values());
  }

  async addItem(insertItem: InsertItem): Promise<Item> {
    const id = this.currentId++;
    const item: Item = { ...insertItem, id };
    this.items.set(id, item);
    this.saveToLocalStorage();
    return item;
  }

  async deleteItem(id: number): Promise<void> {
    this.items.delete(id);
    this.saveToLocalStorage();
  }
}

export const storage = new MemStorage();