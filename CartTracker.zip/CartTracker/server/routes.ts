import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertItemSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  app.get("/api/items", async (_req, res) => {
    const items = await storage.getItems();
    res.json(items);
  });

  app.post("/api/items", async (req, res) => {
    const parsed = insertItemSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid item data" });
      return;
    }

    const item = await storage.addItem(parsed.data);
    res.json(item);
  });

  app.delete("/api/items/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ message: "Invalid item ID" });
      return;
    }

    await storage.deleteItem(id);
    res.status(204).end();
  });

  return createServer(app);
}
