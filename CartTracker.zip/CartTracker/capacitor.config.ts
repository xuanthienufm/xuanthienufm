import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.shopping.assistant',
  appName: 'Shopping Assistant',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https',
    cleartext: true,
    allowNavigation: ['*']
  },
  plugins: {
    LiveUpdates: {
      autoUpdateEnabled: false,
      maxVersions: 2
    }
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false,
    minSdkVersion: 21,
    buildOptions: {
      keystorePath: 'release-key.keystore',
      keystorePassword: 'password',
      keystoreAlias: 'key0',
      keystoreAliasPassword: 'password'
    }
  }
};

export default config;