import type { Item, InsertItem, ShoppingListItem } from "@shared/schema";

const STORAGE_KEY = 'shopping-cart';
const TRIPS_KEY = 'shopping-trips';
const SHOPPING_LIST_KEY = 'shopping-list';

interface ShoppingTrip {
  id: number;
  date: string;
  items: Item[];
  total: number;
  budget: number | null;
  shoppingList: ShoppingListItem[];
}

// Generate a UUID using browser's crypto API
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export class CartStorage {
  private items: Map<number, Item>;
  private trips: Map<number, ShoppingTrip>;
  private currentId: number;
  private currentTripId: number | null;
  private shoppingListId: number;

  constructor() {
    this.items = new Map();
    this.trips = new Map();
    this.currentId = 1;
    this.shoppingListId = 1;
    this.currentTripId = null;
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const savedTrips = window.localStorage.getItem(TRIPS_KEY);
      if (savedTrips) {
        const parsedTrips = JSON.parse(savedTrips);
        this.trips = new Map(parsedTrips.map((trip: ShoppingTrip) => [trip.id, trip]));

        // Find the highest trip ID
        const tripIds = Array.from(this.trips.keys());
        if (tripIds.length > 0) {
          const maxTripId = Math.max(...tripIds);
          this.currentTripId = maxTripId;
        }
      }

      const savedItems = window.localStorage.getItem(STORAGE_KEY);
      if (savedItems) {
        const parsedItems = JSON.parse(savedItems);
        this.items = new Map(parsedItems.map((item: Item) => [item.id, item]));

        // Update currentId based on existing items
        const itemIds = Array.from(this.items.keys());
        if (itemIds.length > 0) {
          this.currentId = Math.max(...itemIds) + 1;
        }
      }
    } catch (error) {
      console.error('Error loading from storage:', error);
      this.items.clear();
      this.trips.clear();
      this.currentId = 1;
      this.currentTripId = null;
    }
  }

  private saveToStorage() {
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(Array.from(this.items.values()))
      );
      window.localStorage.setItem(
        TRIPS_KEY,
        JSON.stringify(Array.from(this.trips.values()))
      );
    } catch (error) {
      console.error('Error saving to storage:', error);
    }
  }

  private getNextTripId(): number {
    const tripIds = Array.from(this.trips.keys());
    return tripIds.length > 0 ? Math.max(...tripIds) + 1 : 1;
  }

  getItems(): Item[] {
    return Array.from(this.items.values());
  }

  getTrips(): ShoppingTrip[] {
    return Array.from(this.trips.values())
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  getTripById(tripId: number): ShoppingTrip | undefined {
    return this.trips.get(tripId);
  }

  getCurrentTripId(): number | null {
    return this.currentTripId;
  }

  getCurrentTrip(): ShoppingTrip | undefined {
    return this.currentTripId ? this.trips.get(this.currentTripId) : undefined;
  }

  addItem(insertItem: InsertItem): Item {
    if (!this.currentTripId) {
      throw new Error('Vui lòng tạo phiên mua sắm mới trước khi thêm sản phẩm');
    }

    const id = this.currentId++;
    const purchaseId = generateUUID();
    const item: Item = {
      ...insertItem,
      id,
      purchaseId,
      createdAt: new Date()
    };

    // Add to items map
    this.items.set(id, item);

    // Update current trip
    const trip = this.trips.get(this.currentTripId);
    if (!trip) {
      throw new Error('Không tìm thấy phiên mua sắm hiện tại');
    }

    trip.items = Array.from(this.items.values());
    trip.total = trip.items.reduce((sum, item) => sum + item.price, 0);
    this.trips.set(this.currentTripId, trip);

    this.saveToStorage();
    return item;
  }

  createTrip(budget?: number): ShoppingTrip {
    // Close any existing trip
    if (this.currentTripId !== null) {
      this.finishTrip();
    }

    const id = this.getNextTripId();
    const trip: ShoppingTrip = {
      id,
      date: new Date().toISOString(),
      items: [],
      total: 0,
      budget: budget || null,
      shoppingList: []
    };

    this.currentTripId = id;
    this.trips.set(id, trip);
    this.items.clear(); // Clear items when creating new trip
    this.saveToStorage();

    return trip;
  }

  reopenTrip(tripId: number): void {
    const trip = this.trips.get(tripId);
    if (!trip) throw new Error('Trip not found');

    this.currentTripId = tripId;
    this.items.clear();

    trip.items.forEach(item => {
      this.items.set(item.id, item);
      if (item.id >= this.currentId) {
        this.currentId = item.id + 1;
      }
    });

    this.saveToStorage();
  }

  updateTripBudget(tripId: number, budget: number): void {
    const trip = this.trips.get(tripId);
    if (!trip) throw new Error('Trip not found');

    trip.budget = budget;
    this.trips.set(tripId, trip);
    this.saveToStorage();
  }

  deleteTrip(tripId: number): void {
    if (this.currentTripId === tripId) {
      this.currentTripId = null;
      this.items.clear();
    }
    this.trips.delete(tripId);
    this.saveToStorage();
  }

  deleteItem(id: number): void {
    const item = this.items.get(id);
    if (!item) return;

    // If item has a purchaseId, find and uncheck the corresponding shopping list item
    if (item.purchaseId && this.currentTripId) {
      const trip = this.trips.get(this.currentTripId);
      if (trip && trip.shoppingList) {
        trip.shoppingList = trip.shoppingList.map(listItem => {
          if (listItem.purchaseId === item.purchaseId) {
            return {
              ...listItem,
              isBought: false,
              imageData: null,
              actualPrice: null,
              purchaseId: null
            };
          }
          return listItem;
        });
      }
    }

    this.items.delete(id);

    if (this.currentTripId !== null) {
      const trip = this.trips.get(this.currentTripId);
      if (trip) {
        const currentItems = this.getItems();
        if (currentItems.length === 0) {
          this.deleteTrip(this.currentTripId);
        } else {
          trip.items = currentItems;
          trip.total = currentItems.reduce((sum, item) => sum + item.price, 0);
          this.trips.set(this.currentTripId, trip);
        }
      }
    }

    this.saveToStorage();
  }

  clearCart(): void {
    this.items.clear();
    if (this.currentTripId !== null) {
      this.deleteTrip(this.currentTripId);
    }
    this.saveToStorage();
  }

  finishTrip(): void {
    if (this.currentTripId !== null) {
      const currentItems = this.getItems();
      if (currentItems.length > 0) {
        const trip = this.trips.get(this.currentTripId);
        if (trip) {
          trip.items = currentItems;
          trip.total = currentItems.reduce((sum, item) => sum + item.price, 0);
          this.trips.set(this.currentTripId, trip);
        }
      } else {
        this.trips.delete(this.currentTripId);
      }
      this.saveToStorage();
    }

    this.currentTripId = null;
    this.items.clear();
  }

  updateItemPrice(id: number, newPrice: number): void {
    const item = this.items.get(id);
    if (!item) return;

    item.price = newPrice;
    this.items.set(id, item);

    if (this.currentTripId !== null) {
      const trip = this.trips.get(this.currentTripId);
      if (trip) {
        const currentItems = this.getItems();
        trip.items = currentItems;
        trip.total = currentItems.reduce((sum, item) => sum + item.price, 0);
        this.trips.set(this.currentTripId, trip);
      }
    }

    this.saveToStorage();
  }


  addShoppingListItem(item: Omit<ShoppingListItem, 'id' | 'createdAt' | 'isBought'>): ShoppingListItem {
    if (!this.currentTripId) throw new Error('No active shopping trip');

    const trip = this.trips.get(this.currentTripId);
    if (!trip) throw new Error('Trip not found');

    const newItem: ShoppingListItem = {
      ...item,
      id: this.shoppingListId++,
      isBought: false,
      createdAt: new Date(),
      tripId: this.currentTripId,
      purchaseId: null // Initialize purchaseId to null
    };

    trip.shoppingList = trip.shoppingList || [];
    trip.shoppingList.push(newItem);
    this.trips.set(this.currentTripId, trip);
    this.saveToStorage();

    return newItem;
  }

  markItemAsBought(listItemId: number, imageData: string, actualPrice: number): void {
    if (!this.currentTripId) throw new Error('No active shopping trip');

    const trip = this.trips.get(this.currentTripId);
    if (!trip) throw new Error('Trip not found');

    const listItem = trip.shoppingList?.find(item => item.id === listItemId);
    if (!listItem) throw new Error('Shopping list item not found');

    const purchaseId = generateUUID();

    // Update shopping list item
    trip.shoppingList = trip.shoppingList?.map(item => {
      if (item.id === listItemId) {
        return {
          ...item,
          isBought: true,
          imageData,
          actualPrice,
          purchaseId
        };
      }
      return item;
    });

    // Create corresponding item in the items list
    const id = this.currentId++;
    const item: Item = {
      id,
      name: listItem.name,
      price: actualPrice,
      imageData,
      createdAt: new Date(),
      purchaseId
    };
    this.items.set(id, item);

    // Update trip with new total
    trip.items = Array.from(this.items.values());
    trip.total = trip.items.reduce((sum, item) => sum + item.price, 0);

    this.trips.set(this.currentTripId, trip);
    this.saveToStorage();
  }

  getShoppingList(): ShoppingListItem[] {
    if (!this.currentTripId) return [];
    const trip = this.trips.get(this.currentTripId);
    if (!trip) return [];
    return trip.shoppingList || [];
  }

  updateShoppingListItem(
    id: number,
    updates: Partial<Omit<ShoppingListItem, 'id' | 'createdAt'>>
  ): void {
    if (!this.currentTripId) throw new Error('No active shopping trip');

    const trip = this.trips.get(this.currentTripId);
    if (!trip || !trip.shoppingList) throw new Error('Trip or shopping list not found');

    const itemIndex = trip.shoppingList.findIndex(item => item.id === id);
    if (itemIndex === -1) throw new Error('Shopping list item not found');

    trip.shoppingList[itemIndex] = {
      ...trip.shoppingList[itemIndex],
      ...updates
    };

    this.saveToStorage();
  }

  deleteShoppingListItem(id: number): void {
    if (!this.currentTripId) throw new Error('No active shopping trip');

    const trip = this.trips.get(this.currentTripId);
    if (!trip || !trip.shoppingList) throw new Error('Trip or shopping list not found');

    trip.shoppingList = trip.shoppingList.filter(item => item.id !== id);
    this.saveToStorage();
  }

  getPurchasedItems(): Item[] {
    return Array.from(this.items.values());
  }
}

export const cartStorage = new CartStorage();
export type { ShoppingTrip };