import { z } from "zod";

export const budgetSchema = z.object({
  budget: z.string().min(1).transform(val => parseFloat(val))
});
