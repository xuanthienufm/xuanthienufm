import { useEffect, useRef, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

interface ImageRecognitionProps {
  imageData: string;
  onDetection: (predictions: cocoSsd.DetectedObject[]) => void;
}

export function ImageRecognition({ imageData, onDetection }: ImageRecognitionProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [model, setModel] = useState<cocoSsd.ObjectDetection | null>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const loadModel = async () => {
      try {
        // Load the COCO-SSD model
        const loadedModel = await cocoSsd.load({
          base: 'lite_mobilenet_v2'  // Using a lighter model for better performance
        });
        setModel(loadedModel);
      } catch (error) {
        console.error('Failed to load TensorFlow model:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadModel();
  }, []);

  useEffect(() => {
    const detectObjects = async () => {
      if (!model || !imageRef.current) return;

      try {
        setIsLoading(true);
        // Run detection on the image
        const predictions = await model.detect(imageRef.current);
        
        // Filter predictions to only include relevant items (fruits, vegetables, etc.)
        const relevantPredictions = predictions.filter(pred => 
          ['banana', 'apple', 'orange', 'carrot', 'broccoli', 'vegetable', 'fruit']
          .includes(pred.class.toLowerCase())
        );

        onDetection(relevantPredictions);
      } catch (error) {
        console.error('Detection failed:', error);
      } finally {
        setIsLoading(false);
      }
    };

    if (model && imageRef.current) {
      detectObjects();
    }
  }, [model, imageData, onDetection]);

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0 relative">
        <img
          ref={imageRef}
          src={imageData}
          alt="Captured item"
          className="w-full h-48 object-cover"
          style={{ opacity: isLoading ? 0.7 : 1 }}
        />
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/50">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
