import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface CurrencySelectProps {
  onSelect: (currency: string) => void;
}

const currencies = [
  { code: "VND", symbol: "₫", name: "Việt Nam Đồng" },
  { code: "USD", symbol: "$", name: "US Dollar" },
];

export function CurrencySelect({ onSelect }: CurrencySelectProps) {
  return (
    <div className="fixed inset-0 bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-neumorph">
        <CardContent className="p-6 space-y-6">
          <h2 className="text-2xl font-bold text-center">Chọn đơn vị tiền tệ</h2>
          <div className="grid grid-cols-1 gap-4">
            {currencies.map((currency) => (
              <Button
                key={currency.code}
                variant="neumorph"
                className="h-auto py-6 flex items-center justify-between"
                onClick={() => onSelect(currency.code)}
              >
                <span className="text-lg">{currency.name}</span>
                <span className="text-2xl font-bold">{currency.symbol}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}