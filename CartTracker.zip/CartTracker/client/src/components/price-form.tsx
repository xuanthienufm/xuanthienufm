import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

const formSchema = z.object({
  price: z.coerce.number().min(0, "Giá phải lớn hơn 0"),
  name: z.string().min(1, "Vui lòng nhập tên sản phẩm").optional()
});

interface PriceFormProps {
  imageData: string;
  onSubmit: (data: { price: number; imageData: string; name: string }) => void;
  onRetake: () => void;
  isLoading: boolean;
  currency: string;
  shoppingListItem?: { name: string; quantity: string };
}

function compressImage(dataUrl: string): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const MAX_WIDTH = 600;
      const MAX_HEIGHT = 600;
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }
      } else {
        if (height > MAX_HEIGHT) {
          width *= MAX_HEIGHT / height;
          height = MAX_HEIGHT;
        }
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);

      resolve(canvas.toDataURL('image/jpeg', 0.7));
    };
    img.src = dataUrl;
  });
}

export function PriceForm({ imageData, onSubmit, onRetake, isLoading, currency, shoppingListItem }: PriceFormProps) {
  const [compressedImage, setCompressedImage] = useState<string | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      price: 0,
      name: shoppingListItem?.name || "",
    },
  });

  const handleSubmit = async (data: z.infer<typeof formSchema>) => {
    let finalImageData = imageData;
    if (!compressedImage) {
      finalImageData = await compressImage(imageData);
      setCompressedImage(finalImageData);
    } else {
      finalImageData = compressedImage;
    }

    onSubmit({ 
      price: data.price, 
      imageData: finalImageData, 
      name: shoppingListItem?.name || data.name || "Sản phẩm mới"
    });
  };

  return (
    <div className="space-y-4">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          {/* Image preview */}
          <div className="flex gap-4 items-start">
            <div className="relative w-24 h-24 shrink-0">
              <img
                src={imageData}
                alt="Captured item"
                className="w-full h-full rounded-lg object-cover border-2 border-primary/20"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={onRetake}
                className="absolute bottom-2 right-2 bg-background/80 backdrop-blur-sm hover:bg-background/90"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex-1">
              {shoppingListItem ? (
                <>
                  <h3 className="font-medium text-lg">{shoppingListItem.name}</h3>
                  <p className="text-sm text-muted-foreground">{shoppingListItem.quantity}</p>
                </>
              ) : (
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tên sản phẩm</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="VD: Cà rốt"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>
          </div>

          <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Giá ({currency})</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="number"
                    step="1000"
                    placeholder="0"
                    className="text-2xl h-16 text-center"
                  />
                </FormControl>
                <FormMessage className="text-base" />
              </FormItem>
            )}
          />

          <Button
            type="submit"
            className="w-full h-14 text-lg gap-2"
            disabled={isLoading}
          >
            Thêm vào giỏ
          </Button>
        </form>
      </Form>
    </div>
  );
}