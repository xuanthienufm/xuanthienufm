import { useState } from "react";
import { ShoppingListItem } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Camera, Check, Plus, ShoppingBasket, ChevronLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cartStorage } from "@/lib/storage";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { PriceForm } from "@/components/price-form";

interface ShoppingListProps {
  onItemBought?: () => void;
}

type RenderItemsProps = {
  items: ShoppingListItem[];
  onCapture: (id: number) => void;
};

function RenderItems({ items, onCapture }: RenderItemsProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <ShoppingBasket className="h-12 w-12 mx-auto mb-2" />
        <p>Chưa có món nào trong danh sách</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <AnimatePresence mode="popLayout">
        {items.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            <Card className={`
              p-3 flex items-center gap-4
              ${item.isBought ? 'bg-muted' : 'hover:bg-accent/5'}
              border-none shadow-none transition-colors
            `}>
              <div className="h-4 w-4 relative shrink-0">
                {item.isBought ? (
                  <Check className="h-4 w-4 text-primary absolute" />
                ) : (
                  <div className="h-4 w-4 border-2 border-muted-foreground/30 rounded-sm" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className={`font-medium truncate ${item.isBought ? 'line-through text-muted-foreground' : ''}`}>
                  {item.name}
                </h4>
                <p className="text-sm text-muted-foreground truncate">
                  {item.quantity}
                </p>
              </div>
              {!item.isBought && (
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 shrink-0 rounded-full hover:bg-accent hover:text-accent-foreground"
                  onClick={() => onCapture(item.id)}
                >
                  <Camera className="h-4 w-4" />
                </Button>
              )}
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

export function ShoppingList({ onItemBought }: ShoppingListProps) {
  const [items, setItems] = useState<ShoppingListItem[]>(cartStorage.getShoppingList());
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemNote, setNewItemNote] = useState("");
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const { toast } = useToast();

  const purchasedItems = items.filter(item => item.isBought);
  const unpurchasedItems = items.filter(item => !item.isBought);

  const handleAdd = () => {
    if (!newItemName.trim()) return;

    try {
      cartStorage.addShoppingListItem({
        name: newItemName.trim(),
        quantity: newItemNote.trim() || "1",
        category: "Khác",
        estimatedPrice: 0,
        tripId: cartStorage.getCurrentTripId() || 0,
        imageData: null,
        actualPrice: null,
        purchaseId: null
      });
      setItems(cartStorage.getShoppingList());
      setNewItemName("");
      setNewItemNote("");
      setShowAddDialog(false);
      toast({
        title: "Thành công",
        description: "Đã thêm món vào danh sách mua sắm",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể thêm món vào danh sách",
        variant: "destructive",
      });
    }
  };

  const handleCapture = (itemId: number) => {
    const cameraCapture = document.createElement('input');
    cameraCapture.type = 'file';
    cameraCapture.accept = 'image/*';
    cameraCapture.capture = 'environment';
    cameraCapture.click();

    cameraCapture.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setCapturedImage(reader.result as string);
          setSelectedItemId(itemId);
        };
        reader.readAsDataURL(file);
      }
    };
  };

  const handleAddToCart = async (data: { price: number; imageData: string; name: string }) => {
    try {
      if (!selectedItemId) return;

      cartStorage.markItemAsBought(selectedItemId, data.imageData, data.price);
      setItems(cartStorage.getShoppingList());
      setCapturedImage(null);
      setSelectedItemId(null);
      // Call the onItemBought callback to update the parent component
      onItemBought?.();
      toast({
        title: "Thành công",
        description: "Đã thêm món vào giỏ hàng",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể thêm món vào giỏ hàng",
        variant: "destructive",
      });
    }
  };

  const selectedItem = selectedItemId ? items.find(item => item.id === selectedItemId) : null;

  return (
    <div className="h-full flex flex-col max-h-[calc(100vh-8rem)] overflow-hidden">
      {capturedImage && selectedItem ? (
        // Capture and price form view
        <>
          <div className="flex items-center gap-2 p-4 border-b">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setCapturedImage(null);
                setSelectedItemId(null);
              }}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h2 className="text-xl font-semibold">Thêm giá</h2>
          </div>

          <div className="flex-1 overflow-auto p-4">
            <PriceForm
              imageData={capturedImage}
              onSubmit={handleAddToCart}
              onRetake={() => handleCapture(selectedItem.id)}
              isLoading={false}
              currency="VND"
              shoppingListItem={{
                name: selectedItem.name,
                quantity: selectedItem.quantity
              }}
            />
          </div>
        </>
      ) : (
        // Shopping list view
        <>
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-xl font-semibold">Danh sách cần mua</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowAddDialog(true)}
            >
              <Plus className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex-1 overflow-auto">
            <Tabs defaultValue="unpurchased" className="w-full">
              <div className="sticky top-0 bg-background/80 backdrop-blur-sm z-10 px-4 pt-4">
                <TabsList className="w-full">
                  <TabsTrigger value="all" className="flex-1">
                    Tất cả ({items.length})
                  </TabsTrigger>
                  <TabsTrigger value="unpurchased" className="flex-1">
                    Chưa mua ({unpurchasedItems.length})
                  </TabsTrigger>
                  <TabsTrigger value="purchased" className="flex-1">
                    Đã mua ({purchasedItems.length})
                  </TabsTrigger>
                </TabsList>
              </div>

              <div className="p-4">
                <TabsContent value="all">
                  <RenderItems items={items} onCapture={handleCapture} />
                </TabsContent>
                <TabsContent value="unpurchased">
                  <RenderItems items={unpurchasedItems} onCapture={handleCapture} />
                </TabsContent>
                <TabsContent value="purchased">
                  <RenderItems items={purchasedItems} onCapture={handleCapture} />
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </>
      )}

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Thêm món cần mua</DialogTitle>
            <DialogDescription>
              Nhập tên món và ghi chú (nếu có) để thêm vào danh sách.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Input
                placeholder="Tên món (VD: Cà rốt)"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
              />
              <Input
                placeholder="Ghi chú (VD: 2kg)"
                value={newItemNote}
                onChange={(e) => setNewItemNote(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowAddDialog(false)}
                className="flex-1"
              >
                Hủy
              </Button>
              <Button
                onClick={handleAdd}
                className="flex-1"
                disabled={!newItemName.trim()}
              >
                Thêm
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}