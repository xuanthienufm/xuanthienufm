import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Camera, ChevronRight, List, ShoppingBag, BarChart2 } from "lucide-react";

const features = [
  {
    icon: Camera,
    title: "Chụp ảnh & Nhận diện tự động",
    description: "Chỉ cần chụp ảnh sản phẩm, app sẽ tự động nhận diện và gợi ý tên cho bạn."
  },
  {
    icon: List,
    title: "Ghi chép chi tiêu dễ dàng",
    description: "Giao diện đơn giản, thân thiện giúp bạn ghi chép chi tiêu nhanh chóng."
  },
  {
    icon: ShoppingBag,
    title: "Hoạt động offline",
    description: "Không cần internet, app vẫn hoạt động bình thường khi bạn đi chợ."
  },
  {
    icon: BarChart2,
    title: "Thống kê chi tiết",
    description: "Xem lại chi tiêu theo ngày, theo danh mục để quản lý tài chính tốt hơn."
  }
];

export function WelcomeScreen({ onComplete }: { onComplete: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Tự động chuyển slide sau 3 giây
    const timer = setInterval(() => {
      if (currentIndex < features.length - 1) {
        setCurrentIndex(prev => prev + 1);
      }
    }, 3000);

    return () => clearInterval(timer);
  }, [currentIndex]);

  const handleComplete = () => {
    setIsVisible(false);
    // Lưu trạng thái đã xem welcome screen
    window.localStorage.setItem('welcomed', 'true');
    setTimeout(onComplete, 300);
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-background flex items-center justify-center p-4"
    >
      <div className="w-full max-w-lg space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Chào mừng bạn!</h1>
          <p className="text-muted-foreground">
            Hãy để chúng tôi giúp bạn quản lý chi tiêu thông minh hơn
          </p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            {features.map((feature, index) => {
              const Icon = feature.icon;
              const isActive = index === currentIndex;
              return (
                <Card
                  key={index}
                  className={`transition-opacity duration-300 ${
                    isActive ? 'opacity-100' : 'opacity-40'
                  }`}
                >
                  <CardContent className="p-4 flex items-start gap-4">
                    <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-semibold">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </motion.div>
        </AnimatePresence>

        <div className="flex items-center justify-between">
          <div className="flex gap-1">
            {features.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                  index === currentIndex ? 'bg-primary' : 'bg-primary/20'
                }`}
              />
            ))}
          </div>
          <Button onClick={handleComplete} className="gap-2">
            Bắt đầu ngay
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
