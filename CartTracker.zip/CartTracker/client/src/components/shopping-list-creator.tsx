import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, Plus, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cartStorage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

interface ShoppingListCreatorProps {
  onBack: () => void;
  onFinish: () => void;
}

interface ListItem {
  name: string;
  note: string;
}

export function ShoppingListCreator({ onBack, onFinish }: ShoppingListCreatorProps) {
  const [items, setItems] = useState<ListItem[]>([]);
  const [currentName, setCurrentName] = useState("");
  const [currentNote, setCurrentNote] = useState("");
  const { toast } = useToast();

  const handleAdd = () => {
    if (!currentName.trim()) return;

    setItems([...items, { name: currentName.trim(), note: currentNote.trim() }]);
    setCurrentName("");
    setCurrentNote("");
  };

  const handleSave = () => {
    try {
      // Add all items to the shopping list
      items.forEach(item => {
        cartStorage.addShoppingListItem({
          name: item.name,
          quantity: item.note || "1",
          category: "Khác",
          estimatedPrice: 0,
          tripId: cartStorage.getCurrentTripId() || 0,
          imageData: null,
          actualPrice: null,
          purchaseId: null
        });
      });

      toast({
        title: "Thành công",
        description: "Đã lưu danh sách mua sắm",
      });

      onFinish();
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể lưu danh sách mua sắm",
        variant: "destructive",
      });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: "100%" }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: "-100%" }}
      className="fixed inset-0 bg-background p-4 z-50"
    >
      <div className="container max-w-lg mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold">Danh sách mua sắm</h1>
        </div>

        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Tên món (VD: Cà rốt)"
              value={currentName}
              onChange={(e) => setCurrentName(e.target.value)}
              className="flex-1"
            />
            <Input
              placeholder="Ghi chú (VD: 2kg)"
              value={currentNote}
              onChange={(e) => setCurrentNote(e.target.value)}
              className="w-1/3"
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={handleAdd}
              disabled={!currentName.trim()}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            {items.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-muted rounded-lg"
              >
                <div>
                  <h3 className="font-medium">{item.name}</h3>
                  {item.note && (
                    <p className="text-sm text-muted-foreground">{item.note}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="fixed bottom-8 left-4 right-4">
          <div className="container max-w-lg mx-auto">
            <Button
              className="w-full h-14 gap-2"
              onClick={handleSave}
              disabled={items.length === 0}
            >
              <Save className="h-4 w-4" />
              Lưu danh sách
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}