import { motion } from "framer-motion";
import { ChevronLeft } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { budgetSchema } from "@/schemas/budget";
import { Button } from "@/components/ui/button";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";

interface BudgetScreenProps {
  onSubmit: (budget: number, createList: boolean) => void;
  onSkip: () => void;
  onBack: () => void;
}

const formSchema = z.object({
  budget: z.string().transform(val => parseFloat(val) || 0),
  createList: z.boolean().default(false)
});

export function BudgetScreen({ onSubmit, onSkip, onBack }: BudgetScreenProps) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      budget: "",
      createList: false
    }
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="min-h-screen bg-background p-4"
    >
      <div className="container max-w-lg mx-auto space-y-8">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-4xl font-bold">Đặt ngân sách</h1>
        </div>

        <div className="space-y-4">
          <p className="text-xl text-muted-foreground leading-relaxed">
            Bạn có thể đặt ngân sách để quản lý chi tiêu tốt hơn. 
            Bạn sẽ được nhắc nhở khi gần hết ngân sách.
          </p>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(data => onSubmit(data.budget, data.createList))} className="space-y-6">
              <FormField
                control={form.control}
                name="budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-lg">Ngân sách (VND)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        step="1000"
                        placeholder="0"
                        className="text-2xl h-16 text-center"
                      />
                    </FormControl>
                    <FormMessage className="text-base" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="createList"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-0.5">
                      <FormLabel>Tạo danh sách mua sắm</FormLabel>
                      <p className="text-sm text-muted-foreground">
                        Lên danh sách những món cần mua trước khi đi chợ
                      </p>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="grid gap-4">
                <Button 
                  type="submit" 
                  size="lg"
                  className="h-14 text-lg"
                >
                  Xác nhận
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  onClick={onSkip}
                  className="h-14 text-lg"
                >
                  Bỏ qua, không cần ngân sách
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </motion.div>
  );
}