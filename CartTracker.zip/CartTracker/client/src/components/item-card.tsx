import type { Item } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, Clock, Pencil } from "lucide-react";
import { motion, useAnimation } from "framer-motion";
import { format } from "date-fns";

interface ItemCardProps {
  item: Item;
  onDelete: (id: number) => void;
  onEdit: () => void;
  isDeleting: boolean;
  layout?: "grid" | "list";
  currency: string;
}

export function ItemCard({ item, onDelete, onEdit, isDeleting, layout = "list", currency }: ItemCardProps) {
  const controls = useAnimation();

  const handleSwipe = async (_, info) => {
    if (info.offset.x > 100) { 
      await controls.start({ x: "100%", opacity: 0 });
      onDelete(item.id);
    } else {
      controls.start({ x: 0, opacity: 1 });
    }
  };

  const formatPrice = () => {
    if (currency === 'VND') {
      return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(item.price);
    }
    return `$${item.price.toFixed(2)}`;
  };

  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: 0, right: 100 }}
      onDragEnd={handleSwipe}
      animate={controls}
      className="relative"
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{
        layout: { duration: 0.3 },
        opacity: { duration: 0.2 },
        y: { type: "spring", stiffness: 300, damping: 30 }
      }}
    >
      <Card 
        className={`
          overflow-hidden 
          ${layout === 'list' ? 'flex items-center' : ''} 
          p-4 
          hover:bg-accent/5 
          transition-all 
          duration-200 
          border-0
          bg-card/50 
          backdrop-blur-sm
        `}
      >
        <div className={`
          ${layout === 'list' ? 'w-16 h-16' : 'w-20 h-20 mx-auto mb-3'} 
          relative shrink-0 rounded-2xl overflow-hidden 
          shadow-[0_2px_10px_rgba(0,0,0,0.1)]
          border border-border/50
        `}>
          <img 
            src={item.imageData} 
            alt={item.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className={`
          flex-1 
          ${layout === 'list' ? 'ml-4 flex items-center justify-between' : 'text-center'}
        `}>
          <div>
            <h3 className="font-medium text-base leading-tight tracking-tight">{item.name}</h3>
            <p className="text-primary font-medium mt-0.5 tracking-tight">
              {formatPrice()}
            </p>
            <div className="flex items-center gap-1 mt-1.5 text-xs text-muted-foreground justify-center">
              <Clock className="h-3 w-3" />
              <span>{format(new Date(item.createdAt), 'HH:mm')}</span>
            </div>
          </div>
          <div className="flex gap-1.5">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit()}
              className="h-8 w-8 shrink-0 rounded-full hover:bg-accent hover:text-accent-foreground"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(item.id);
              }}
              disabled={isDeleting}
              className="h-8 w-8 shrink-0 rounded-full hover:bg-destructive/10 hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}