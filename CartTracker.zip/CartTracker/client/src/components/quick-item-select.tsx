import { Button } from "@/components/ui/button";
import { 
  Coffee, Pizza, Apple, Shirt, Book, Gift, ShoppingBag,
  Baby, Beef, Carrot, Fish, Cookie, Milk, Wine,
  Sandwich, Smartphone, Watch, Tv, Lamp, Bath
} from "lucide-react";

interface QuickItemSelectProps {
  onSelect: (name: string) => void;
}

const quickItems = [
  {
    group: "Thực phẩm",
    items: [
      { icon: Carrot, name: "Rau củ" },
      { icon: Apple, name: "Trái cây" },
      { icon: Beef, name: "Thịt" },
      { icon: Fish, name: "Hải sản" },
      { icon: Pizza, name: "Đồ ăn" },
      { icon: Sandwich, name: "Bánh mì" },
      { icon: Cookie, name: "Bánh kẹo" },
    ]
  },
  {
    group: "Đồ uống",
    items: [
      { icon: Coffee, name: "Cà phê" },
      { icon: Wine, name: "Nước uống" },
      { icon: Milk, name: "Sữa" },
    ]
  },
  {
    group: "Đồ dùng",
    items: [
      { icon: Smartphone, name: "Điện thoại" },
      { icon: Tv, name: "Điện tử" },
      { icon: Lamp, name: "Gia dụng" },
      { icon: Bath, name: "Đồ vệ sinh" },
    ]
  },
  {
    group: "Khác",
    items: [
      { icon: Shirt, name: "Quần áo" },
      { icon: Book, name: "Sách vở" },
      { icon: Baby, name: "Đồ trẻ em" },
      { icon: Gift, name: "Quà tặng" },
      { icon: ShoppingBag, name: "Khác" },
    ]
  }
];

export function QuickItemSelect({ onSelect }: QuickItemSelectProps) {
  return (
    <div className="space-y-4">
      {quickItems.map((group) => (
        <div 
          key={group.group} 
          className="p-4 rounded-lg border-2 bg-card shadow-lg"
        >
          <h3 className="font-bold mb-4 text-lg">{group.group}</h3>
          <div className="grid grid-cols-4 gap-4">
            {group.items.map((item) => (
              <Button
                key={item.name}
                variant="ghost"
                size="lg"
                className="aspect-square flex flex-col gap-2 items-center justify-center hover:bg-accent hover:text-accent-foreground"
                onClick={() => onSelect(item.name)}
              >
                <item.icon className="h-9 w-9" />
                <span className="text-xs text-center font-semibold">{item.name}</span>
              </Button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}