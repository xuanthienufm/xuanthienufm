import { Home, ShoppingBag, BarChart2, Settings } from "lucide-react";
import { Link, useLocation } from "wouter";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Lịch sử" },
    { href: "/shopping", icon: ShoppingBag, label: "Đi chợ" },
    { href: "/statistics", icon: BarChart2, label: "Thống kê" },
    { href: "/settings", icon: Settings, label: "Cài đặt" }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-lg border-t">
      <div className="container max-w-lg mx-auto">
        <div className="grid grid-cols-4 gap-1 p-2">
          {navItems.map(({ href, icon: Icon, label }) => {
            const isActive = location === href;
            return (
              <Link 
                key={href} 
                href={href}
                className={`
                  flex flex-col items-center gap-1 p-2 rounded-lg
                  ${isActive ? 'text-primary' : 'text-muted-foreground'}
                  transition-colors hover:text-primary
                `}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}