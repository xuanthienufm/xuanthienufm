import { Card, CardContent } from "@/components/ui/card";
import { Calculator, Wallet, Settings } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

interface TotalDisplayProps {
  total: number;
  currency: string;
  budget?: number | null;
  onEditBudget?: () => void;
}

export function TotalDisplay({ total, currency, budget, onEditBudget }: TotalDisplayProps) {
  const formatMoney = (amount: number) => {
    if (currency === 'VND') {
      return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    }
    return `$${amount.toFixed(2)}`;
  };

  const remaining = budget ? budget - total : null;
  const progressPercent = budget ? (total / budget) * 100 : 0;

  return (
    <Card className={`${budget && remaining && remaining < 0 ? 'bg-destructive' : 'bg-primary'} text-primary-foreground`}>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            <span className="font-bold">Tổng tiền</span>
          </div>
          <span className="text-2xl font-extrabold">
            {formatMoney(total)}
          </span>
        </div>

        {budget && (
          <>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4" />
                <span>Ngân sách: {formatMoney(budget)}</span>
                {onEditBudget && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 hover:bg-primary-foreground/20"
                    onClick={onEditBudget}
                  >
                    <Settings className="h-3 w-3" />
                  </Button>
                )}
              </div>
              <span>
                Còn lại: {formatMoney(remaining || 0)}
              </span>
            </div>
            <Progress 
              value={progressPercent} 
              className="h-2 bg-primary-foreground/20" 
              indicatorClassName="bg-primary-foreground"
            />
          </>
        )}
      </CardContent>
    </Card>
  );
}