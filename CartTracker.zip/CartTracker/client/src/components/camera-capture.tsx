import { useState, useEffect as ReactuseEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

interface CameraCaptureProps {
  onCapture: (imageData: string) => void;
}

export function CameraCapture({ onCapture }: CameraCaptureProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment' // Prefer rear camera on mobile
        } 
      });
      setStream(mediaStream);
      setError(null);
    } catch (err) {
      console.error('Camera error:', err);
      if ((err as Error).name === 'NotAllowedError') {
        setError("Vui lòng cho phép truy cập camera trong trình duyệt của bạn");
      } else if ((err as Error).name === 'NotFoundError') {
        setError("Không tìm thấy camera. Vui lòng kiểm tra thiết bị của bạn");
      } else {
        setError("Không thể mở camera. Vui lòng thử lại sau");
      }
    }
  };

  const capturePhoto = () => {
    if (!stream) return;

    const video = document.createElement('video');
    video.srcObject = stream;

    // Make sure video is ready
    video.onloadedmetadata = () => {
      video.play();

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setError("Không thể chụp ảnh. Vui lòng thử lại");
        return;
      }

      ctx.drawImage(video, 0, 0);
      const imageData = canvas.toDataURL('image/jpeg');
      onCapture(imageData);

      // Stop camera after capturing
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    };
  };

  // Clean up on unmount
  ReactuseEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  return (
    <Card className="p-4">
      {error && (
        <div className="mb-4 p-3 bg-destructive/10 text-destructive rounded-lg">
          {error}
        </div>
      )}

      {stream ? (
        <div className="space-y-4">
          <video 
            autoPlay 
            playsInline
            ref={(videoEl) => {
              if (videoEl) {
                videoEl.srcObject = stream;
                // Mute to avoid feedback
                videoEl.muted = true;
              }
            }}
            className="w-full rounded-lg"
          />
          <Button 
            onClick={capturePhoto}
            className="w-full"
          >
            Chụp ảnh
          </Button>
        </div>
      ) : (
        <Button 
          onClick={startCamera}
          className="w-full"
          variant="outline"
        >
          <Camera className="mr-2 h-4 w-4" />
          Mở Camera
        </Button>
      )}
    </Card>
  );
}