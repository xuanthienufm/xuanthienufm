import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { Salad, Carrot, Banana, Apple } from "lucide-react";

interface VegetableInfo {
  name: string;
  benefits: string;
  icon: React.ReactNode;
  season: string;
}

const healthyVegetables: VegetableInfo[] = [
  {
    name: "Rau ngót",
    benefits: "Tăng cường sức đề kháng, giải nhiệt",
    icon: <Salad className="w-full h-full text-green-600" />,
    season: "Quanh năm"
  },
  {
    name: "Bắp cải",
    benefits: "Giàu vitamin C và K, tốt cho xương",
    icon: <Salad className="w-full h-full text-green-500" />,
    season: "Mùa đông"
  },
  {
    name: "Rau cải",
    benefits: "Phòng chống ung thư, tốt cho gan",
    icon: <Salad className="w-full h-full text-green-400" />,
    season: "Mùa thu - đông"
  },
  {
    name: "Cà rốt",
    benefits: "Giàu beta-carotene, tốt cho mắt",
    icon: <Carrot className="w-full h-full text-orange-500" />,
    season: "Quanh năm"
  }
];

export function HealthyVegetablesSuggestion() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTextVisible, setIsTextVisible] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const readTimeRef = useRef<NodeJS.Timeout>();

  // Calculate marquee duration based on text length
  const getMarqueeDuration = () => {
    const text = healthyVegetables[currentIndex].benefits;
    // Use character count to determine duration
    // Approximately 30 characters per second
    return `${Math.max(text.length / 30, 10)}s`;
  };

  useEffect(() => {
    // Reset the visibility state
    setIsTextVisible(true);
    setIsPaused(false);

    // Calculate time needed for one complete scroll
    const duration = parseFloat(getMarqueeDuration()) * 1000;

    // Clear any existing timers
    if (timerRef.current) clearTimeout(timerRef.current);
    if (readTimeRef.current) clearTimeout(readTimeRef.current);

    // Wait for the text to finish scrolling once
    timerRef.current = setTimeout(() => {
      if (!isPaused) {
        setIsTextVisible(false); // Start fade out
      }
    }, duration + 500); // Add 500ms buffer

    // After fade out animation, change to next vegetable
    readTimeRef.current = setTimeout(() => {
      if (!isPaused) {
        setCurrentIndex((current) =>
          current === healthyVegetables.length - 1 ? 0 : current + 1
        );
      }
    }, duration + 1000); // Add 1s for fade out

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (readTimeRef.current) clearTimeout(readTimeRef.current);
    };
  }, [currentIndex, isPaused]);

  return (
    <Card className="overflow-hidden bg-[#fff9c4] border-[#fff176] backdrop-blur shadow-glow-primary">
      <CardContent className="p-4 relative">
        {/* Enhanced post-it note design elements */}
        <div className="absolute -top-1 -right-1 w-8 h-8 bg-[#fff176] transform rotate-45 origin-bottom-left" />
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-b from-[#fff9c4]/50 to-transparent" />

        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: isTextVisible ? 1 : 0, y: isTextVisible ? 0 : -20 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{
              opacity: { duration: 0.5 },
              y: { type: "spring", stiffness: 300, damping: 30 }
            }}
            className="flex items-start gap-4"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
          >
            <div className="w-20 h-20 shrink-0">
              {healthyVegetables[currentIndex].icon}
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-lg text-primary">
                {healthyVegetables[currentIndex].name}
              </h3>
              <p className="text-sm text-muted-foreground mb-1">
                Mùa: {healthyVegetables[currentIndex].season}
              </p>
              <div className="overflow-hidden">
                <p 
                  className={`text-sm text-foreground whitespace-nowrap ${isPaused ? 'animate-paused' : 'animate-marquee-once'}`}
                  style={{ 
                    animationDuration: getMarqueeDuration(),
                    animationTimingFunction: 'linear',
                  }}
                >
                  {healthyVegetables[currentIndex].benefits}
                </p>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}