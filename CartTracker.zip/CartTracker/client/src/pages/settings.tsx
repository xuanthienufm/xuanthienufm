import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Moon, Sun, DollarSign, Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cartStorage } from "@/lib/storage";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

function vibrate(duration:number){
  if (typeof navigator.vibrate === 'function') {
    navigator.vibrate(duration);
  }
}

export default function Settings() {
  const [isDark, setIsDark] = useState(() => {
    const stored = window.localStorage.getItem('theme');
    if (stored) {
      return stored === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [showIntro, setShowIntro] = useState(false);

  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const toggleTheme = () => {
    setIsDark(!isDark);
    if (!isDark) {
      document.documentElement.classList.add('dark');
      window.localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      window.localStorage.setItem('theme', 'light');
    }
    vibrate(10);
  };

  const exportData = () => {
    try {
      const data = {
        trips: cartStorage.getTrips(),
        currentTrip: {
          id: cartStorage.getCurrentTripId(),
          items: cartStorage.getItems()
        }
      };

      // Tạo text để chia sẻ trên mobile
      const textData = JSON.stringify(data, null, 2);

      if (navigator.share) {
        // Sử dụng Web Share API cho mobile
        navigator.share({
          title: 'Dữ liệu mua sắm',
          text: textData,
        }).catch(() => {
          // Fallback khi share thất bại
          const blob = new Blob([textData], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `shopping-data-${new Date().toISOString().split('T')[0]}.txt`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        });
      } else {
        // Fallback cho desktop
        const blob = new Blob([textData], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `shopping-data-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      toast({
        title: "Thành công",
        description: "Đã xuất dữ liệu thành công",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể xuất dữ liệu",
        variant: "destructive",
      });
    }
  };

  const menuItems = [
    {
      icon: isDark ? Sun : Moon,
      label: "Giao diện",
      value: isDark ? "Tối" : "Sáng",
      onClick: toggleTheme
    },
    {
      icon: DollarSign,
      label: "Đơn vị tiền tệ",
      value: "VND",
      href: "/currency"
    },
    {
      icon: Info,
      label: "Giới thiệu",
      onClick: () => setShowIntro(true)
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-lg mx-auto p-4 space-y-6">
        <h1 className="text-2xl font-bold">Cài đặt</h1>

        <Card>
          <CardContent className="p-0">
            <div className="divide-y">
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`
                      w-full justify-start px-4 py-6 rounded-none
                      ${index === 0 ? 'rounded-t-lg' : ''}
                      ${index === menuItems.length - 1 ? 'rounded-b-lg' : ''}
                    `}
                    onClick={item.onClick}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5" />
                        <span>{item.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.value && (
                          <span className="text-sm text-muted-foreground">
                            {item.value}
                          </span>
                        )}
                      </div>
                    </div>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <AnimatePresence>
        {showIntro && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background"
          >
            <div className="flex flex-col items-center justify-center min-h-screen p-4">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 100 }}
                className="space-y-8 text-center"
              >
                <motion.p 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="text-2xl font-bold"
                >
                  Dành cho ví tiền của bạn, hạn chế mua những thứ bạn muốn, hãy mua những thứ bạn cần!
                </motion.p>
                <motion.p
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="text-lg text-muted-foreground"
                >
                  - BXT.2025 -
                </motion.p>
              </motion.div>
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                onClick={() => setShowIntro(false)}
                className="mt-12 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Nhấn để tiếp tục
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}