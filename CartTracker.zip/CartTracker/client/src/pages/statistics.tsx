import { useState } from "react";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ChevronLeft, PieChart as PieChartIcon, BarChart as BarChartIcon } from "lucide-react";
import { cartStorage } from "@/lib/storage";
import { useLocation } from "wouter";
import type { Item } from "@shared/schema";

export default function StatisticsPage() {
  const [, setLocation] = useLocation();
  const [view, setView] = useState<'daily' | 'category'>('daily');
  const items = cartStorage.getItems();

  // Calculate data for daily chart
  const dailyData = items.reduce((acc: Record<string, number>, item: Item) => {
    const date = format(new Date(item.createdAt), 'dd/MM');
    acc[date] = (acc[date] || 0) + item.price;
    return acc;
  }, {});

  const dailyChartData = Object.entries(dailyData)
    .map(([date, total]) => ({
      date,
      total
    }))
    .slice(-7); // Only show last 7 days

  // Calculate data by category
  const categoryData = items.reduce((acc: Record<string, number>, item: Item) => {
    acc[item.name] = (acc[item.name] || 0) + item.price;
    return acc;
  }, {});

  const categoryChartData = Object.entries(categoryData)
    .map(([category, total]) => ({
      category,
      total
    }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 10); // Top 10 categories

  // Calculate total spending
  const totalSpent = items.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="container max-w-lg mx-auto p-4 space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold">Thống kê chi tiêu</h1>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Tổng chi tiêu</p>
              <p className="text-4xl font-bold mt-1">
                {new Intl.NumberFormat('vi-VN', { 
                  style: 'currency', 
                  currency: 'VND' 
                }).format(totalSpent)}
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-2">
          <Button
            variant={view === 'daily' ? 'default' : 'outline'}
            onClick={() => setView('daily')}
            className="flex-1"
          >
            <BarChartIcon className="mr-2 h-4 w-4" />
            Theo ngày
          </Button>
          <Button
            variant={view === 'category' ? 'default' : 'outline'}
            onClick={() => setView('category')}
            className="flex-1"
          >
            <PieChartIcon className="mr-2 h-4 w-4" />
            Theo danh mục
          </Button>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={view === 'daily' ? dailyChartData : categoryChartData}
                  margin={{ top: 20, right: 0, left: 0, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey={view === 'daily' ? 'date' : 'category'} 
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis />
                  <Tooltip />
                  <Bar 
                    dataKey="total" 
                    fill="hsl(var(--primary))"
                    radius={[4, 4, 0, 0]} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}