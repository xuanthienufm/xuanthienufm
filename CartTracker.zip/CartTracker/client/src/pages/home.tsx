import { useState, useEffect } from "react";
import type { Item, InsertItem } from "@shared/schema";
import { PriceForm } from "@/components/price-form";
import { ItemCard } from "@/components/item-card";
import { TotalDisplay } from "@/components/total-display";
import { CurrencySelect } from "@/components/currency-select";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Moon, Sun, ShoppingBag,
  Package, CalendarDays, Wallet, Trash2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cartStorage, type ShoppingTrip } from "@/lib/storage";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { useLocation } from "wouter";
import { BudgetScreen } from "@/components/budget-screen";
import { AnimatePresence } from "framer-motion";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { ShoppingListCreator } from "@/components/shopping-list-creator";

// Function to trigger haptic feedback
const vibrate = (pattern: number | number[] = 10) => {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
  }
};

function TripCard({ trip, onDelete, onReopen }: {
  trip: ShoppingTrip;
  onDelete: (id: number) => void;
  onReopen: (id: number) => void;
}) {
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);

  return (
    <>
      <Card
        className="overflow-hidden hover:bg-accent/50 cursor-pointer transition-colors"
        onClick={() => onReopen(trip.id)}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <CalendarDays className="h-4 w-4" />
                <span className="text-sm">
                  {format(new Date(trip.date), 'EEEE, dd/MM/yyyy', { locale: vi })}
                </span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Package className="h-4 w-4" />
                <span className="text-sm">{trip.items.length} món</span>
              </div>
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4" />
                <span className="font-medium">
                  {new Intl.NumberFormat('vi-VN', {
                    style: 'currency',
                    currency: 'VND'
                  }).format(trip.total)}
                </span>
                {trip.budget && (
                  <span className={`text-sm ${trip.total > trip.budget ? 'text-destructive' : 'text-muted-foreground'}`}>
                    / {new Intl.NumberFormat('vi-VN', {
                      style: 'currency',
                      currency: 'VND'
                    }).format(trip.budget)}
                  </span>
                )}
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation(); // Prevent card click when deleting
                setShowDeleteAlert(true);
              }}
              className="hover:bg-accent hover:text-accent-foreground"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Xác nhận xóa</AlertDialogTitle>
            <AlertDialogDescription>
              Bạn có chắc chắn muốn xóa phiên đi chợ này? Hành động này không thể hoàn tác.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowDeleteAlert(false)}>
              Hủy
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                onDelete(trip.id);
                setShowDeleteAlert(false);
              }}
              className="bg-destructive hover:bg-destructive/90"
            >
              Xóa
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

export default function Home() {
  const [trips, setTrips] = useState<ShoppingTrip[]>([]);
  const [isDark, setIsDark] = useState(() => {
    const stored = window.localStorage.getItem('theme');
    if (stored) {
      return stored === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [showBudgetScreen, setShowBudgetScreen] = useState(false);
  const [showShoppingList, setShowShoppingList] = useState(false);

  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Load trips from localStorage on mount
  useEffect(() => {
    setTrips(cartStorage.getTrips());
  }, []);

  // Initialize theme on mount
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const handleStartShopping = () => {
    setShowBudgetScreen(true);
    vibrate([10, 50, 10]);
  };

  const handleSetBudget = (budget: number, createList: boolean) => {
    try {
      cartStorage.createTrip(budget);
      setShowBudgetScreen(false);
      if (createList) {
        setShowShoppingList(true);
      } else {
        setLocation('/shopping');
      }
      vibrate([10, 50, 10]);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể tạo phiên mua sắm mới",
        variant: "destructive",
      });
    }
  };

  const handleSkipBudget = () => {
    try {
      cartStorage.createTrip();
      setShowBudgetScreen(false);
      setLocation('/shopping');
      vibrate([10, 50, 10]);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể tạo phiên mua sắm mới",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTrip = (tripId: number) => {
    try {
      cartStorage.deleteTrip(tripId);
      setTrips(cartStorage.getTrips());
      vibrate([10, 30, 10]); // Delete vibration pattern
      toast({
        title: "Thành công",
        description: "Đã xóa phiên mua sắm",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể xóa phiên mua sắm",
        variant: "destructive",
      });
    }
  };

  const handleReopenTrip = (tripId: number) => {
    try {
      cartStorage.reopenTrip(tripId);
      setLocation('/shopping');
      vibrate([10, 50, 10]);
      toast({
        title: "Thành công",
        description: "Đã mở lại phiên mua sắm",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể mở lại phiên mua sắm",
        variant: "destructive",
      });
    }
  };

  const handleFinishList = () => {
    setShowShoppingList(false);
    setLocation('/shopping');
  };


  const toggleTheme = () => {
    setIsDark(!isDark);
    if (!isDark) {
      document.documentElement.classList.add('dark');
      window.localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      window.localStorage.setItem('theme', 'light');
    }
    vibrate(10);
  };

  if (showBudgetScreen) {
    return (
      <AnimatePresence mode="wait">
        <BudgetScreen
          onSubmit={handleSetBudget}
          onSkip={handleSkipBudget}
          onBack={() => setShowBudgetScreen(false)}
        />
      </AnimatePresence>
    );
  }

  if (showShoppingList) {
    return (
      <AnimatePresence mode="wait">
        <ShoppingListCreator
          onBack={() => setShowShoppingList(false)}
          onFinish={handleFinishList}
        />
      </AnimatePresence>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-lg mx-auto p-4 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Lịch sử</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
          >
            {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
        </div>

        <div className="grid gap-4">
          {trips.length === 0 ? (
            <Card className="p-8 text-center">
              <CardContent className="space-y-2">
                <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground" />
                <p className="text-muted-foreground">
                  Chưa có lần đi chợ nào. Hãy bắt đầu!
                </p>
              </CardContent>
            </Card>
          ) : (
            trips.map(trip => (
              <TripCard
                key={trip.id}
                trip={trip}
                onDelete={handleDeleteTrip}
                onReopen={handleReopenTrip}
              />
            ))
          )}
        </div>
      </div>

      <div className="fixed bottom-24 left-1/2 -translate-x-1/2">
        <Button
          variant="default"
          size="lg"
          className="h-16 px-8 rounded-full shadow-lg bg-primary hover:bg-primary/90 font-medium"
          onClick={handleStartShopping}
        >
          <ShoppingBag className="mr-2 h-6 w-6" />
          Đi chợ
        </Button>
      </div>
    </div>
  );
}