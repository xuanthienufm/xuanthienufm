import { useState, useEffect } from "react";
import type { Item, InsertItem } from "@shared/schema";
import { PriceForm } from "@/components/price-form";
import { ItemCard } from "@/components/item-card";
import { TotalDisplay } from "@/components/total-display";
import { HealthyVegetablesSuggestion } from "@/components/healthy-vegetables-suggestion";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ShoppingList } from "@/components/shopping-list";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  CheckSquare2,
  Grid2X2,
  List,
  Camera,
  Moon,
  Sun,
  ChevronLeft,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cartStorage } from "@/lib/storage";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { useLocation } from "wouter";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { BudgetScreen } from "@/components/budget-screen";

// Function to trigger haptic feedback
const vibrate = (pattern: number | number[] = 10) => {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
  }
};

const editPriceSchema = z.object({
  price: z.coerce.number().min(0, "Giá phải lớn hơn 0")
});

export default function Shopping() {
  const [items, setItems] = useState<Item[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [currency, setCurrency] = useState<string>("VND");
  const [isDark, setIsDark] = useState(() => {
    const stored = window.localStorage.getItem('theme');
    if (stored) {
      return stored === 'dark';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [showBudgetScreen, setShowBudgetScreen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(false);
  const [currentTrip, setCurrentTrip] = useState(cartStorage.getCurrentTrip());
  const [openShoppingList, setOpenShoppingList] = useState(false);

  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<z.infer<typeof editPriceSchema>>({
    resolver: zodResolver(editPriceSchema),
    defaultValues: {
      price: 0,
    }
  });

  useEffect(() => {
    if (editingItem) {
      form.reset({
        price: editingItem.price
      });
    }
  }, [editingItem, form]);

  useEffect(() => {
    // Only show budget screen on first load if no trip exists
    const tripId = cartStorage.getCurrentTripId();
    if (!tripId) {
      setShowBudgetScreen(true);
    } else {
      const currentTrip = cartStorage.getCurrentTrip();
      setItems(cartStorage.getPurchasedItems());
      setCurrentTrip(currentTrip);
    }
    setIsLoading(false);
  }, []); // Only run on mount

  // This effect updates items when the trip changes
  useEffect(() => {
    if (currentTrip) {
      setItems(cartStorage.getPurchasedItems());
    }
  }, [currentTrip]);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const handleCapture = () => {
    if (!cartStorage.getCurrentTripId()) {
      toast({
        title: "Thông báo",
        description: "Vui lòng tạo phiên mua sắm mới trước khi thêm sản phẩm",
      });
      setShowBudgetScreen(true);
      return;
    }

    const cameraCapture = document.createElement('input');
    cameraCapture.type = 'file';
    cameraCapture.accept = 'image/*';
    cameraCapture.capture = 'environment';
    cameraCapture.click();

    cameraCapture.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setCapturedImage(reader.result as string);
          vibrate([10, 30]);
        };
        reader.readAsDataURL(file);
      }
    };
  };

  const handleAddItem = (data: { price: number; imageData: string; name: string }) => {
    try {
      if (!cartStorage.getCurrentTripId()) {
        toast({
          title: "Lỗi",
          description: "Vui lòng tạo phiên mua sắm mới trước khi thêm sản phẩm",
          variant: "destructive",
        });
        setShowBudgetScreen(true);
        return;
      }

      const newItem = cartStorage.addItem({
        name: data.name || "Sản phẩm mới",
        price: data.price,
        imageData: data.imageData,
      });

      setItems(cartStorage.getPurchasedItems());
      setCurrentTrip(cartStorage.getCurrentTrip());
      setCapturedImage(null);
      vibrate([10, 50, 10]);

      toast({
        title: "Thành công",
        description: "Đã thêm sản phẩm vào giỏ hàng",
      });
    } catch (error) {
      console.error('Error adding item:', error);
      vibrate(100);
      toast({
        title: "Lỗi",
        description: error instanceof Error ? error.message : "Không thể thêm sản phẩm vào giỏ hàng",
        variant: "destructive",
      });
    }
  };

  const handleDeleteItem = (id: number) => {
    try {
      cartStorage.deleteItem(id);
      setItems(cartStorage.getPurchasedItems());
      setCurrentTrip(cartStorage.getCurrentTrip());
      vibrate([10, 30, 10]); // Delete vibration pattern
      toast({
        title: "Thành công",
        description: "Đã xóa sản phẩm khỏi giỏ hàng",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể xóa sản phẩm",
        variant: "destructive",
      });
    }
  };

  const handleEditPrice = (data: z.infer<typeof editPriceSchema>) => {
    try {
      if (!editingItem) return;
      cartStorage.updateItemPrice(editingItem.id, data.price);
      setItems(cartStorage.getPurchasedItems());
      setCurrentTrip(cartStorage.getCurrentTrip());
      setEditingItem(null);
      vibrate([10, 50, 10]); // Success vibration pattern
      toast({
        title: "Thành công",
        description: "Đã cập nhật giá sản phẩm",
      });
    } catch (error) {
      vibrate(100); // Error vibration
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật giá sản phẩm",
        variant: "destructive",
      });
    }
  };

  const handleBackToHome = () => {
    if (items.length > 0) {
      cartStorage.finishTrip();
    }
    setLocation("/");
  };

  const handleSetBudget = (budget: number) => {
    try {
      cartStorage.createTrip(budget);
      setShowBudgetScreen(false);
      setItems(cartStorage.getPurchasedItems());
      setCurrentTrip(cartStorage.getCurrentTrip());
      vibrate([10, 50, 10]);
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể tạo phiên mua sắm mới",
        variant: "destructive",
      });
    }
  };

  const handleUpdateBudget = (budget: number) => {
    try {
      if (!currentTrip) return;
      cartStorage.updateTripBudget(currentTrip.id, budget);
      setCurrentTrip(cartStorage.getCurrentTrip());
      setEditingBudget(false);
      vibrate([10, 50, 10]);
      toast({
        title: "Thành công",
        description: "Đã cập nhật ngân sách",
      });
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể cập nhật ngân sách",
        variant: "destructive",
      });
    }
  };

  const handleSkipBudget = () => {
    setShowBudgetScreen(false);
    cartStorage.createTrip();
    setItems(cartStorage.getPurchasedItems());
    setCurrentTrip(cartStorage.getCurrentTrip());
  }

  const total = items.reduce((sum, item) => sum + item.price, 0);

  // Group items by date
  const itemsByDate = items.reduce((groups, item) => {
    const date = new Date(item.createdAt);
    const dateStr = format(date, 'dd/MM/yyyy');

    if (!groups[dateStr]) {
      groups[dateStr] = [];
    }
    groups[dateStr].push(item);
    return groups;
  }, {} as Record<string, Item[]>);

  // Sort dates in descending order
  const sortedDates = Object.keys(itemsByDate).sort((a, b) => {
    const dateA = new Date(a.split('/').reverse().join('-'));
    const dateB = new Date(b.split('/').reverse().join('-'));
    return dateB.getTime() - dateA.getTime();
  });

  if (showBudgetScreen) {
    return (
      <AnimatePresence mode="wait">
        <BudgetScreen
          onSubmit={handleSetBudget}
          onSkip={handleSkipBudget}
          onBack={() => setShowBudgetScreen(false)}
        />
      </AnimatePresence>
    );
  }

  if (editingBudget) {
    return (
      <AnimatePresence mode="wait">
        <BudgetScreen
          onSubmit={handleUpdateBudget}
          onSkip={() => setEditingBudget(false)}
          onBack={() => setEditingBudget(false)}
        />
      </AnimatePresence>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="container max-w-lg mx-auto p-4 space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBackToHome}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold">Đi chợ</h1>
          </div>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                const isDark = document.documentElement.classList.contains('dark');
                setIsDark(!isDark);
                if (isDark) {
                  document.documentElement.classList.remove('dark');
                  window.localStorage.setItem('theme', 'light');
                } else {
                  document.documentElement.classList.add('dark');
                  window.localStorage.setItem('theme', 'dark');
                }
                vibrate(10);
              }}
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setViewMode(viewMode === 'grid' ? 'list' : 'grid');
                vibrate(10);
              }}
            >
              {viewMode === 'grid' ? <List className="h-4 w-4" /> : <Grid2X2 className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="shadow-none"
          >
            <TotalDisplay
              total={total}
              currency={currency}
              budget={currentTrip?.budget || null}
              onEditBudget={() => setEditingBudget(true)}
            />
          </motion.div>
        </AnimatePresence>

        <HealthyVegetablesSuggestion />

        {capturedImage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="shadow-none border-none"
          >
            <PriceForm
              imageData={capturedImage}
              onSubmit={handleAddItem}
              onRetake={handleCapture}
              isLoading={false}
              currency={currency}
            />
          </motion.div>
        )}

        {!capturedImage && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            <Button
              variant="default"
              size="lg"
              className="w-full h-14 gap-2 bg-primary hover:bg-primary/90 border-none shadow-none"
              onClick={() => handleCapture()}
            >
              <Camera className="h-5 w-5" />
              Thêm món mới
            </Button>
          </motion.div>
        )}

        {isLoading ? (
          <div className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-2' : ''}`}>
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse h-48 bg-muted rounded-lg border-none shadow-none" />
            ))}
          </div>
        ) : (
          <div className="space-y-8">
            {sortedDates.map(dateStr => (
              <div key={dateStr} className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="h-px flex-grow bg-border/50" />
                  <span className="text-sm font-medium text-muted-foreground">
                    {format(new Date(dateStr.split('/').reverse().join('-')), 'EEEE, dd/MM/yyyy', { locale: vi })}
                  </span>
                  <div className="h-px flex-grow bg-border/50" />
                </div>

                <AnimatePresence>
                  <div className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-2' : ''}`}>
                    {itemsByDate[dateStr].map((item) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ type: "spring", stiffness: 300, damping: 25 }}
                        className="shadow-none border-none"
                      >
                        <ItemCard
                          item={item}
                          onDelete={handleDeleteItem}
                          onEdit={() => setEditingItem(item)}
                          isDeleting={false}
                          layout={viewMode}
                          currency={currency}
                        />
                      </motion.div>
                    ))}
                  </div>
                </AnimatePresence>
              </div>
            ))}
          </div>
        )}

        <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Chỉnh sửa giá cho {editingItem?.name}</DialogTitle>
              <DialogDescription>
                Nhập giá mới cho sản phẩm này. Giá cũ: {editingItem?.price} {currency}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleEditPrice)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Giá ({currency})</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          type="number"
                          step="1000"
                          placeholder="0"
                          className="border-none shadow-none bg-muted"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setEditingItem(null)}
                    className="border-none shadow-none"
                  >
                    Hủy
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 border-none shadow-none"
                  >
                    Lưu thay đổi
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Floating action buttons */}
      <div className="fixed bottom-24 right-4 flex flex-col gap-2">
        {!capturedImage && (
          <Button
            variant="default"
            size="icon"
            className="h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90"
            onClick={() => handleCapture()}
          >
            <Camera className="h-6 w-6" />
          </Button>
        )}
        <Collapsible open={openShoppingList} onOpenChange={setOpenShoppingList}>
          <CollapsibleContent className="fixed bottom-40 right-4 w-[calc(100vw-32px)] sm:w-[420px] h-[calc(100vh-200px)] bg-background border rounded-lg shadow-lg overflow-auto">
            <ShoppingList onItemBought={() => {
              setItems(cartStorage.getPurchasedItems());
              setCurrentTrip(cartStorage.getCurrentTrip());
            }} />
          </CollapsibleContent>
          <CollapsibleTrigger asChild>
            <Button
              variant="default"
              size="icon"
              className="h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90"
            >
              <CheckSquare2 className="h-6 w-6" />
            </Button>
          </CollapsibleTrigger>
        </Collapsible>
      </div>
    </div>
  );
}