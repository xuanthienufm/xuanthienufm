import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

const features = [
  {
    title: "Chụp ảnh & Nhận diện tự động",
    description: "Chỉ cần chụp ảnh sản phẩm, app sẽ tự động nhận diện và gợi ý tên cho bạn."
  },
  {
    title: "Ghi chép chi tiêu dễ dàng",
    description: "Giao diện đơn giản, thân thiện giúp bạn ghi chép chi tiêu nhanh chóng."
  },
  {
    title: "Hoạt động offline",
    description: "Không cần internet, app vẫn hoạt động bình thường khi bạn đi chợ."
  },
  {
    title: "Thống kê chi tiết",
    description: "Xem lại chi tiêu theo ngày, theo danh mục để quản lý tài chính tốt hơn."
  },
  {
    title: "Gợi ý thực phẩm lành mạnh",
    description: "Cập nhật thông tin về rau củ quả theo mùa và lợi ích sức khỏe."
  },
  {
    title: "Hỗ trợ nhiều đơn vị tiền tệ",
    description: "Linh hoạt chuyển đổi giữa VND và USD khi ghi chép."
  }
];

export default function About() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-lg mx-auto p-4 space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/settings")}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold">Về ứng dụng</h1>
        </div>

        <div className="prose prose-sm dark:prose-invert">
          <p className="text-lg">
            Đây là ứng dụng giúp bạn theo dõi chi tiêu khi đi chợ hoặc siêu thị một cách dễ dàng và tiện lợi nhất.
          </p>
        </div>

        <div className="grid gap-4">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-4 rounded-lg border bg-card text-card-foreground"
            >
              <h3 className="font-semibold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="prose prose-sm dark:prose-invert">
          <h2 className="text-xl font-semibold mb-4">Cách sử dụng</h2>
          <ol className="list-decimal pl-4 space-y-2">
            <li>Nhấn nút "Đi chợ" để bắt đầu một phiên mua sắm mới</li>
            <li>Chụp ảnh sản phẩm hoặc chọn từ danh sách có sẵn</li>
            <li>Nhập giá và lưu vào giỏ hàng</li>
            <li>Xem lại lịch sử và thống kê chi tiêu của bạn</li>
          </ol>
        </div>

        <div className="prose prose-sm dark:prose-invert mt-8">
          <p className="text-muted-foreground">
            Phiên bản: 1.0.0
          </p>
        </div>
      </div>
    </div>
  );
}
