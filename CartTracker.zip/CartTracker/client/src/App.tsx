import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { BottomNav } from "@/components/bottom-nav";
import { WelcomeScreen } from "@/components/welcome-screen";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Shopping from "@/pages/shopping";
import Statistics from "@/pages/statistics";
import Settings from "@/pages/settings";
import About from "@/pages/about";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shopping" component={Shopping} />
      <Route path="/statistics" component={Statistics} />
      <Route path="/settings" component={Settings} />
      <Route path="/about" component={About} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { toast } = useToast();
  const [showWelcome, setShowWelcome] = useState(() => {
    return !window.localStorage.getItem('welcomed');
  });

  // Handle online/offline status
  useEffect(() => {
    const handleStatusChange = () => {
      if (navigator.onLine) {
        toast({
          title: "Kết nối lại",
          description: "Đã kết nối lại internet",
          duration: 2000,
        });
      } else {
        toast({
          title: "Mất kết nối",
          description: "Ứng dụng vẫn hoạt động bình thường khi offline",
          duration: 2000,
        });
      }
    };

    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);

    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
    };
  }, [toast]);

  return (
    <QueryClientProvider client={queryClient}>
      {showWelcome && (
        <WelcomeScreen onComplete={() => setShowWelcome(false)} />
      )}
      <div className="pb-[4.5rem]">
        <Router />
        <BottomNav />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;